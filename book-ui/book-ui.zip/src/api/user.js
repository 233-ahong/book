import request from '@/utils/request.js'

export function updateUserPwd() {
  return request()
}

export function uploadAvatar() {
  return request()
}

export function updateUserProfile() {
  return request()
}
